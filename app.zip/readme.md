SETUP Elastic beanstalk ENVIRONMENT

1. setup env variables and need mongo cloud url
2. Make sure entry file should be app.js
3. Click on create application
4. Choose platform node.js
5. upload your code in zip file.
6. and make sure node_odules deleted
7. 
